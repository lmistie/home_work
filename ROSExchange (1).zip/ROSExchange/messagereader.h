#ifndef MESSAGEREADER_H
#define MESSAGEREADER_H

#include <QObject>
#include <QThread>
#include "qamqpexchange.h"
#include "qamqpclient.h"
#include "qamqpqueue.h"
#include <QTimer>
#include <QMutex>

class MessageReader : public QThread
{
    Q_OBJECT

    QAmqpExchange *defaultExchange;

    QAmqpClient client;

    QList<QByteArray> ifktFrames;

    int count = 0, frameNumber = 0;

    QString type;

    QAmqpQueue *commandQueue, *cuQueue, *kpiQueue, *ifktQueue, *tmiIQueue, *tmiQQueue, *cupMessageQueue, *rkoQueue, *fileQueue, *kisMessageQueue;

    QTimer *timer;

    void sendMessage(QByteArray, QString key);

    quint32 messageCount = 0, firstFrameNumber = 0, allMessages = 0;  // Счётчик сообщений

    bool firstFrame = true;

    QMutex *globalMutex;

public:
    MessageReader(QMutex*, QAmqpExchange*, QAmqpQueue*, QList<QByteArray>);

protected:
    virtual void run();

private:
    void connectWithProps(QString ip, int port, QString virtualHost, QString login, QString password, bool autoReconnect);

private slots:
    void clientConnected();
    void queueDeclared();
    void ifktSend();
    void messageReceived();
};

#endif // MESSAGEREADER_H
