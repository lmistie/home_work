#include "mainwindow.h"
#include <QDebug>
#include <QFile>
#include <QDataStream>
#include <QString>
#include <QMutex>


MainWindow::MainWindow(QObject *parent) : QObject(parent)
{
//    qputenv("QAMQP_DEBUG", "true");
    qRegisterMetaType<QAbstractSocket::SocketError>("QAbstractSocket::SocketError");
    qRegisterMetaType<QAbstractSocket::SocketState>("QAbstractSocket::SocketState");
    type = "CUP";
//    type = "KIS";
    if (type == "CUP") {
        connectWithProps("200.200.200.125", 5672, "/", "cup", "cup", true);
    } else {
        connectWithProps("200.200.200.125", 5672, "/", "kis", "kis", true);
    }

//    connectWithProps("200.200.200.125", 5672, "/", "kis", "kis", true);
}

void MainWindow::connectWithProps(QString ip, int port, QString virtualHost, QString login, QString password, bool autoReconnect)
{
    QAmqpClient *client = new QAmqpClient();
    connect(client, SIGNAL(connected()), this, SLOT(clientConnected()));
    connect(client, SIGNAL(socketErrorOccurred(QAbstractSocket::SocketError)), this, SLOT(errorReceived(QAbstractSocket::SocketError)));
//    connect(&client, SIGNAL(disconnected()), this, SLOT(clientDisconnected()));
    clientList.append(client);
    client->setHost(ip);
    client->setPort(port);
    client->setVirtualHost(virtualHost);
    client->setUsername(login);
    client->setPassword(password);
    client->setAutoReconnect(autoReconnect);
//    client->setFrameMax(99999);
    client->setWriteTimeout(5000);
    client->connectToHost();
}

void MainWindow::clientConnected()
{
    QAmqpClient *client = qobject_cast<QAmqpClient*>(sender());

    defaultExchange = client->createExchange("FanOutExchange");
    defaultExchange->declare(QAmqpExchange::FanOut, QAmqpExchange::NoWait);
    defaultExchange->qos(1);

    if (type == "KIS") {
        commandQueue = client->createQueue("Commands");
        disconnect(commandQueue, 0, 0, 0);
        connect(commandQueue, SIGNAL(declared()), this, SLOT(queueDeclared()));
        commandQueue->declare(QAmqpQueue::AutoDelete);

        cuQueue = client->createQueue("CU");
        disconnect(cuQueue, 0, 0, 0);
        connect(cuQueue, SIGNAL(declared()), this, SLOT(queueDeclared()));
        cuQueue->declare(QAmqpQueue::AutoDelete);

        kpiQueue = client->createQueue("KPI");
        disconnect(kpiQueue, 0, 0, 0);
        connect(kpiQueue, SIGNAL(declared()), this, SLOT(queueDeclared()));
        kpiQueue->declare(QAmqpQueue::AutoDelete);

        cupMessageQueue = client->createQueue("MessagesCUP");
        disconnect(cupMessageQueue, 0, 0, 0);
        connect(cupMessageQueue, SIGNAL(declared()), this, SLOT(queueDeclared()));
        cupMessageQueue->declare(QAmqpQueue::AutoDelete);
    } else if (type == "CUP") {
        ifktQueue = client->createQueue("IFKT");
        disconnect(ifktQueue, 0, 0, 0);
        connect(ifktQueue, SIGNAL(declared()), this, SLOT(queueDeclared()));
        ifktQueue->declare(QAmqpQueue::AutoDelete);
//        QThread::msleep(100);

        tmiIQueue = client->createQueue("TMI_I");
        disconnect(tmiIQueue, 0, 0, 0);
        connect(tmiIQueue, SIGNAL(declared()), this, SLOT(queueDeclared()));
        tmiIQueue->declare(QAmqpQueue::AutoDelete);
//        QThread::msleep(100);

        tmiQQueue = client->createQueue("TMI_Q");
        disconnect(tmiQQueue, 0, 0, 0);
        connect(tmiQQueue, SIGNAL(declared()), this, SLOT(queueDeclared()));
        tmiQQueue->declare(QAmqpQueue::AutoDelete);
//        QThread::msleep(100);

        rkoQueue = client->createQueue("RKO");
        disconnect(rkoQueue, 0, 0, 0);
        connect(rkoQueue, SIGNAL(declared()), this, SLOT(queueDeclared()));
        rkoQueue->declare(QAmqpQueue::AutoDelete);
//        QThread::msleep(100);

        fileQueue = client->createQueue("FILE");
        disconnect(fileQueue, 0, 0, 0);
        connect(fileQueue, SIGNAL(declared()), this, SLOT(queueDeclared()));
        fileQueue->declare(QAmqpQueue::AutoDelete);
//        QThread::msleep(100);

        kisMessageQueue = client->createQueue("MessagesKIS");
        disconnect(kisMessageQueue, 0, 0, 0);
        connect(kisMessageQueue, SIGNAL(declared()), this, SLOT(queueDeclared()));
        kisMessageQueue->declare(QAmqpQueue::AutoDelete);
//        QThread::msleep(100);

    } else if (type == "VIEWER") {
        ifktQueue = client->createQueue("IFKT");
        disconnect(ifktQueue, 0, 0, 0);
        connect(ifktQueue, SIGNAL(declared()), this, SLOT(queueDeclared()));
        ifktQueue->declare(QAmqpQueue::AutoDelete);
    }
}

void MainWindow::queueDeclared() {
    QAmqpQueue *queue = qobject_cast<QAmqpQueue*>(sender());
    if (!queue)
        return;

    if (type == "KIS") {
        if (queue == commandQueue) {
            connect(commandQueue, SIGNAL(messageReceived()), this, SLOT(messageReceived()));
            commandQueue->consume(QAmqpQueue::coNoAck);
            qDebug() << " [*] Waiting for messages from commandQueue.";
        } else if (queue == cuQueue) {
            connect(cuQueue, SIGNAL(messageReceived()), this, SLOT(messageReceived()));
            cuQueue->consume(QAmqpQueue::coNoAck);
            qDebug() << " [*] Waiting for messages from cuQueue.";
        } else if (queue == kpiQueue) {
            connect(kpiQueue, SIGNAL(messageReceived()), this, SLOT(messageReceived()));
            kpiQueue->consume(QAmqpQueue::coNoAck);
            qDebug() << " [*] Waiting for messages from kpiQueue.";
        } else if (queue == cupMessageQueue) {
            connect(cupMessageQueue, SIGNAL(messageReceived()), this, SLOT(messageReceived()));
            cupMessageQueue->consume(QAmqpQueue::coNoAck);
            qDebug() << " [*] Waiting for messages from cupMessageQueue. To exit press CTRL+C";

            count = 0;
            readIfktFromFile();
//            startSenderThread();
//            startSenderThread();
//            startSenderThread();
            timer = new QTimer();
            connect(timer, SIGNAL(timeout()), this, SLOT(ifktSend()));
            timer->start(1);
        }
    } else if (type == "CUP") {
        if (queue == ifktQueue) {
//            connect(ifktQueue, SIGNAL(messageReceived()), this, SLOT(messageReceived()));
            ifktQueue->consume(QAmqpQueue::coNoAck);
            ifktQueue->bind(defaultExchange, "IFKT");
            qDebug() << " [*] Waiting for messages from ifktQueue.";
//            startSenderThread();
            queuesCount++;
        } else if (queue == tmiIQueue) {
            connect(tmiIQueue, SIGNAL(messageReceived()), this, SLOT(messageReceived()));
            tmiIQueue->consume(QAmqpQueue::coNoAck);
            qDebug() << " [*] Waiting for messages from tmiIQueue.";
            queuesCount++;
        } else if (queue == tmiQQueue) {
            connect(tmiQQueue, SIGNAL(messageReceived()), this, SLOT(messageReceived()));
            tmiQQueue->consume(QAmqpQueue::coNoAck);
            qDebug() << " [*] Waiting for messages from tmiQQueue.";
            queuesCount++;
        } else if (queue == rkoQueue) {
            connect(rkoQueue, SIGNAL(messageReceived()), this, SLOT(messageReceived()));
            rkoQueue->consume(QAmqpQueue::coNoAck);
            qDebug() << " [*] Waiting for messages from rkoQueue.";
            queuesCount++;
        } else if (queue == fileQueue) {
            connect(fileQueue, SIGNAL(messageReceived()), this, SLOT(messageReceived()));
            fileQueue->consume(QAmqpQueue::coNoAck);
            qDebug() << " [*] Waiting for messages from fileQueue.";
            queuesCount++;
        } else if (queue == kisMessageQueue) {
            connect(kisMessageQueue, SIGNAL(messageReceived()), this, SLOT(messageReceived()));
            kisMessageQueue->consume(QAmqpQueue::coNoAck);
            qDebug() << " [*] Waiting for messages from kisMessageQueue. To exit press CTRL+C";
            queuesCount++;
//            startSenderThread();
//            startSenderThread();
//            startSenderThread();
        }
    } else if (type == "VIEWER") {
            connect(ifktQueue, SIGNAL(messageReceived()), this, SLOT(messageReceived()));
            ifktQueue->consume(QAmqpQueue::coNoAck);
            ifktQueue->bind(defaultExchange, "IFKT");
            qDebug() << " [*] Waiting for messages from ifktQueue. To exit press CTRL+C";
    }
    if (type == "CUP") {
        if (queuesCount == 6) {
            startSenderThread();
        }
    }
}

void MainWindow::messageReceived() {
    QAmqpQueue *queue = qobject_cast<QAmqpQueue*>(sender());
    if (!queue)
        return;

//    while (!queue->isEmpty()) {
//queue->
    QAmqpMessage message = queue->dequeue();
    QByteArray frameNumberBytes = message.payload().left(sizeof(quint32));
    QByteArray timeFromFrame = message.payload().mid(4, sizeof(quint32));

    qDebug() << "Frames - " << queue->messageCount();
    quint32 *packageNumber = reinterpret_cast<quint32*>(frameNumberBytes.data());
    int *frameTime = reinterpret_cast<int*>(timeFromFrame.data());
    //    QDataStream stream(packetNumberBytes);
    //    stream.setByteOrder(QDataStream::BigEndian);
    //    stream >> packetNumber;

    if (firstFrame || *packageNumber == 0)
    {
        firstFrameNumber = *packageNumber;
        messageCount = 0;
        firstFrame = false;
    }

    int time = QTime::currentTime().msecsSinceStartOfDay();
    qDebug() << " [x] Received from " << queue->name() << "\n Data - "<< message.payload().toHex() << "\n Size - \t\t\t" << message.payload().size() <<
                "\n Number frame recieved - \t" << /*QString::number(*/*packageNumber <<
                "\n Message number index count - \t" << firstFrameNumber + messageCount << "(" << allMessages << ")" << "\n Ping - " << time - *frameTime << QTime::currentTime().toString("hh:mm:ss:zzz");
    messageCount++;
    allMessages++;
//    }
}

void MainWindow::sendMessage(QByteArray data, QString key)
{
    QAmqpMessage::PropertyHash properties;
    properties[QAmqpMessage::DeliveryMode] = "1";   // make message persistent
    int time = QTime::currentTime().msecsSinceStartOfDay();
    data.prepend(reinterpret_cast<const char*>(&time), sizeof(int));
    data.prepend(reinterpret_cast<const char*>(&frameNumber), sizeof(frameNumber));
    defaultExchange->publish(data, key, "Bytes", properties);
    /*
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    defaultExchange->publish(data, key, "Bytes", properties);
    */
    qDebug() << " [x] Send to " << key << " - " << data.toHex() << " Size - " << data.size() << " Frame number - " << frameNumber << QTime::currentTime().toString("hh:mm:ss:zzz");
    frameNumber++;
}

void MainWindow::readIfktFromFile()
{
    QFile *file = new QFile(QCoreApplication::applicationDirPath() + "/data/ifktData.if");
    file->open(QIODevice::ReadOnly);

    QByteArray fileData = file->read(256);
    while (fileData.size() != 0) {
        if (fileData.size() < 256) {
            fileData.resize(256);
        }
        ifktFrames.append(fileData);
        fileData = file->read(256);
    }
    file->close();
//    startSenderThread();
//    startSenderThread();
//    startSenderThread();
}

void MainWindow::startSenderThread()
{
    globalMutex = new QMutex();
    MessageReader *messageReader = new MessageReader(globalMutex, defaultExchange, ifktQueue, ifktFrames);
//    defaultExchange->moveToThread(messageReader);
    readersList.append(messageReader);
    messageReader->start();
}

void MainWindow::ifktSend()
{
    if (defaultExchange->isOpen()) {
        sendMessage(ifktFrames.at(count), "IFKT");

        count++;
        if (count == ifktFrames.count()) {
            count = 0;
        }
    }
}

void MainWindow::errorReceived(QAbstractSocket::SocketError error) {
    QString errorString;
    switch (error) {
    case QAbstractSocket::SocketError::HostNotFoundError:
        errorString = "HostNotFoundError";
        break;
    case QAbstractSocket::SocketError::SocketAccessError:
        errorString = "SocketAccessError";
        break;
    case QAbstractSocket::SocketError::SocketTimeoutError:
        errorString = "SocketTimeoutError";
        break;
    case QAbstractSocket::SocketError::ConnectionRefusedError:
        errorString = "ConnectionRefusedError";
        break;
    case QAbstractSocket::SocketError::RemoteHostClosedError:
        errorString = "RemoteHostClosedError";
        break;
    case QAbstractSocket::SocketError::SocketResourceError:
        errorString = "SocketResourceError";
        break;
    case QAbstractSocket::SocketError::DatagramTooLargeError:
        errorString = "DatagramTooLargeError";
        break;
    case QAbstractSocket::SocketError::NetworkError:
        errorString = "NetworkError";
        break;
    case QAbstractSocket::SocketError::AddressInUseError:
        errorString = "AddressInUseError";
        break;
    case QAbstractSocket::SocketError::SocketAddressNotAvailableError:
        errorString = "SocketAddressNotAvailableError";
        break;
    case QAbstractSocket::SocketError::UnsupportedSocketOperationError:
        errorString = "UnsupportedSocketOperationError";
        break;
    case QAbstractSocket::SocketError::UnfinishedSocketOperationError:
        errorString = "UnfinishedSocketOperationError";
        break;
    case QAbstractSocket::SocketError::ProxyAuthenticationRequiredError:
        errorString = "ProxyAuthenticationRequiredError";
        break;
    case QAbstractSocket::SocketError::SslHandshakeFailedError:
        errorString = "SslHandshakeFailedError";
        break;
    case QAbstractSocket::SocketError::ProxyConnectionRefusedError:
        errorString = "ProxyConnectionRefusedError";
        break;
    case QAbstractSocket::SocketError::ProxyConnectionClosedError:
        errorString = "ProxyConnectionClosedError";
        break;
    case QAbstractSocket::SocketError::ProxyConnectionTimeoutError:
        errorString = "ProxyConnectionTimeoutError";
        break;
    case QAbstractSocket::SocketError::ProxyNotFoundError:
        errorString = "ProxyNotFoundError";
        break;
    case QAbstractSocket::SocketError::ProxyProtocolError:
        errorString = "ProxyProtocolError";
        break;
    case QAbstractSocket::SocketError::OperationError:
        errorString = "OperationError";
        break;
    case QAbstractSocket::SocketError::SslInternalError:
        errorString = "SslInternalError";
        break;
    case QAbstractSocket::SocketError::SslInvalidUserDataError:
        errorString = "SslInvalidUserDataError";
        break;
    case QAbstractSocket::SocketError::TemporaryError:
        errorString = "TemporaryError";
        break;
    case QAbstractSocket::SocketError::UnknownSocketError:
        errorString = "UnknownSocketError";
        break;
    }
    qDebug() << "Error occured: " + errorString;
}

MainWindow::~MainWindow()
{

}
