#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QObject>
#include <QCoreApplication>
#include "qamqpclient.h"
#include "qamqpexchange.h"
#include "qamqpqueue.h"
#include <QTimer>
#include "messagereader.h"

class MainWindow : public QObject
{
    Q_OBJECT

//    QAmqpClient client;
    QList<QAmqpClient*> clientList;

    QAmqpQueue *commandQueue, *cuQueue, *kpiQueue, *ifktQueue, *tmiIQueue, *tmiQQueue, *cupMessageQueue, *rkoQueue, *fileQueue, *kisMessageQueue;

    QAmqpExchange *defaultExchange;

    QString type;

    QTimer *timer;

    QList<QByteArray> ifktFrames;

    int queuesCount = 0, count, frameNumber = 0;

//    MessageReader *messageReader;
    QList<MessageReader*> readersList;

    QMutex *globalMutex;

    void sendMessage(QByteArray, QString key);

    void readIfktFromFile();

    void startSenderThread();

public:
    MainWindow(QObject *parent = 0);
    ~MainWindow();
private:
    void connectWithProps(QString ip, int port, QString virtualHost, QString login, QString password, bool autoReconnect);

    quint32 messageCount = 0, firstFrameNumber = 0, allMessages = 0;  // Счётчик сообщений

    bool firstFrame = true;

private slots:
    void clientConnected();
    void messageReceived();
    void queueDeclared();
    void ifktSend();
    void errorReceived(QAbstractSocket::SocketError);
};

#endif // MAINWINDOW_H
