/****************************************************************************
** Meta object code from reading C++ file 'qamqpqueue.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../qamqpqueue.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qamqpqueue.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_QAmqpQueue_t {
    QByteArrayData data[55];
    char stringdata0[496];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QAmqpQueue_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QAmqpQueue_t qt_meta_stringdata_QAmqpQueue = {
    {
QT_MOC_LITERAL(0, 0, 10), // "QAmqpQueue"
QT_MOC_LITERAL(1, 11, 8), // "declared"
QT_MOC_LITERAL(2, 20, 0), // ""
QT_MOC_LITERAL(3, 21, 5), // "bound"
QT_MOC_LITERAL(4, 27, 7), // "unbound"
QT_MOC_LITERAL(5, 35, 7), // "removed"
QT_MOC_LITERAL(6, 43, 6), // "purged"
QT_MOC_LITERAL(7, 50, 12), // "messageCount"
QT_MOC_LITERAL(8, 63, 15), // "messageReceived"
QT_MOC_LITERAL(9, 79, 5), // "empty"
QT_MOC_LITERAL(10, 85, 9), // "consuming"
QT_MOC_LITERAL(11, 95, 11), // "consumerTag"
QT_MOC_LITERAL(12, 107, 9), // "cancelled"
QT_MOC_LITERAL(13, 117, 7), // "declare"
QT_MOC_LITERAL(14, 125, 7), // "options"
QT_MOC_LITERAL(15, 133, 10), // "QAmqpTable"
QT_MOC_LITERAL(16, 144, 9), // "arguments"
QT_MOC_LITERAL(17, 154, 4), // "bind"
QT_MOC_LITERAL(18, 159, 12), // "exchangeName"
QT_MOC_LITERAL(19, 172, 3), // "key"
QT_MOC_LITERAL(20, 176, 14), // "QAmqpExchange*"
QT_MOC_LITERAL(21, 191, 8), // "exchange"
QT_MOC_LITERAL(22, 200, 6), // "unbind"
QT_MOC_LITERAL(23, 207, 5), // "purge"
QT_MOC_LITERAL(24, 213, 6), // "remove"
QT_MOC_LITERAL(25, 220, 7), // "consume"
QT_MOC_LITERAL(26, 228, 3), // "get"
QT_MOC_LITERAL(27, 232, 5), // "noAck"
QT_MOC_LITERAL(28, 238, 6), // "cancel"
QT_MOC_LITERAL(29, 245, 6), // "noWait"
QT_MOC_LITERAL(30, 252, 3), // "ack"
QT_MOC_LITERAL(31, 256, 12), // "QAmqpMessage"
QT_MOC_LITERAL(32, 269, 7), // "message"
QT_MOC_LITERAL(33, 277, 11), // "deliveryTag"
QT_MOC_LITERAL(34, 289, 8), // "multiple"
QT_MOC_LITERAL(35, 298, 6), // "reject"
QT_MOC_LITERAL(36, 305, 7), // "requeue"
QT_MOC_LITERAL(37, 313, 11), // "QueueOption"
QT_MOC_LITERAL(38, 325, 9), // "NoOptions"
QT_MOC_LITERAL(39, 335, 7), // "Passive"
QT_MOC_LITERAL(40, 343, 7), // "Durable"
QT_MOC_LITERAL(41, 351, 9), // "Exclusive"
QT_MOC_LITERAL(42, 361, 10), // "AutoDelete"
QT_MOC_LITERAL(43, 372, 6), // "NoWait"
QT_MOC_LITERAL(44, 379, 12), // "QueueOptions"
QT_MOC_LITERAL(45, 392, 13), // "ConsumeOption"
QT_MOC_LITERAL(46, 406, 9), // "coNoLocal"
QT_MOC_LITERAL(47, 416, 7), // "coNoAck"
QT_MOC_LITERAL(48, 424, 11), // "coExclusive"
QT_MOC_LITERAL(49, 436, 8), // "coNoWait"
QT_MOC_LITERAL(50, 445, 12), // "RemoveOption"
QT_MOC_LITERAL(51, 458, 7), // "roForce"
QT_MOC_LITERAL(52, 466, 10), // "roIfUnused"
QT_MOC_LITERAL(53, 477, 9), // "roIfEmpty"
QT_MOC_LITERAL(54, 487, 8) // "roNoWait"

    },
    "QAmqpQueue\0declared\0\0bound\0unbound\0"
    "removed\0purged\0messageCount\0messageReceived\0"
    "empty\0consuming\0consumerTag\0cancelled\0"
    "declare\0options\0QAmqpTable\0arguments\0"
    "bind\0exchangeName\0key\0QAmqpExchange*\0"
    "exchange\0unbind\0purge\0remove\0consume\0"
    "get\0noAck\0cancel\0noWait\0ack\0QAmqpMessage\0"
    "message\0deliveryTag\0multiple\0reject\0"
    "requeue\0QueueOption\0NoOptions\0Passive\0"
    "Durable\0Exclusive\0AutoDelete\0NoWait\0"
    "QueueOptions\0ConsumeOption\0coNoLocal\0"
    "coNoAck\0coExclusive\0coNoWait\0RemoveOption\0"
    "roForce\0roIfUnused\0roIfEmpty\0roNoWait"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QAmqpQueue[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      29,   14, // methods
       2,  238, // properties
       4,  244, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  159,    2, 0x06 /* Public */,
       3,    0,  160,    2, 0x06 /* Public */,
       4,    0,  161,    2, 0x06 /* Public */,
       5,    0,  162,    2, 0x06 /* Public */,
       6,    1,  163,    2, 0x06 /* Public */,
       8,    0,  166,    2, 0x06 /* Public */,
       9,    0,  167,    2, 0x06 /* Public */,
      10,    1,  168,    2, 0x06 /* Public */,
      12,    1,  171,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      13,    2,  174,    2, 0x0a /* Public */,
      13,    1,  179,    2, 0x2a /* Public | MethodCloned */,
      13,    0,  182,    2, 0x2a /* Public | MethodCloned */,
      17,    2,  183,    2, 0x0a /* Public */,
      17,    2,  188,    2, 0x0a /* Public */,
      22,    2,  193,    2, 0x0a /* Public */,
      22,    2,  198,    2, 0x0a /* Public */,
      23,    0,  203,    2, 0x0a /* Public */,
      24,    1,  204,    2, 0x0a /* Public */,
      24,    0,  207,    2, 0x2a /* Public | MethodCloned */,
      25,    1,  208,    2, 0x0a /* Public */,
      25,    0,  211,    2, 0x2a /* Public | MethodCloned */,
      26,    1,  212,    2, 0x0a /* Public */,
      26,    0,  215,    2, 0x2a /* Public | MethodCloned */,
      28,    1,  216,    2, 0x0a /* Public */,
      28,    0,  219,    2, 0x2a /* Public | MethodCloned */,
      30,    1,  220,    2, 0x0a /* Public */,
      30,    2,  223,    2, 0x0a /* Public */,
      35,    2,  228,    2, 0x0a /* Public */,
      35,    2,  233,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   11,
    QMetaType::Void, QMetaType::QString,   11,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, 0x80000000 | 15,   14,   16,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   18,   19,
    QMetaType::Void, 0x80000000 | 20, QMetaType::QString,   21,   19,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   18,   19,
    QMetaType::Void, 0x80000000 | 20, QMetaType::QString,   21,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void,
    QMetaType::Bool, QMetaType::Int,   14,
    QMetaType::Bool,
    QMetaType::Void, QMetaType::Bool,   27,
    QMetaType::Void,
    QMetaType::Bool, QMetaType::Bool,   29,
    QMetaType::Bool,
    QMetaType::Void, 0x80000000 | 31,   32,
    QMetaType::Void, QMetaType::LongLong, QMetaType::Bool,   33,   34,
    QMetaType::Void, 0x80000000 | 31, QMetaType::Bool,   32,   36,
    QMetaType::Void, QMetaType::LongLong, QMetaType::Bool,   33,   36,

 // properties: name, type, flags
      14, QMetaType::Int, 0x00095401,
      11, QMetaType::QString, 0x00095103,

 // enums: name, alias, flags, count, data
      37,   37, 0x0,    6,  264,
      44,   37, 0x0,    6,  276,
      45,   45, 0x0,    4,  288,
      50,   50, 0x0,    4,  296,

 // enum data: key, value
      38, uint(QAmqpQueue::NoOptions),
      39, uint(QAmqpQueue::Passive),
      40, uint(QAmqpQueue::Durable),
      41, uint(QAmqpQueue::Exclusive),
      42, uint(QAmqpQueue::AutoDelete),
      43, uint(QAmqpQueue::NoWait),
      38, uint(QAmqpQueue::NoOptions),
      39, uint(QAmqpQueue::Passive),
      40, uint(QAmqpQueue::Durable),
      41, uint(QAmqpQueue::Exclusive),
      42, uint(QAmqpQueue::AutoDelete),
      43, uint(QAmqpQueue::NoWait),
      46, uint(QAmqpQueue::coNoLocal),
      47, uint(QAmqpQueue::coNoAck),
      48, uint(QAmqpQueue::coExclusive),
      49, uint(QAmqpQueue::coNoWait),
      51, uint(QAmqpQueue::roForce),
      52, uint(QAmqpQueue::roIfUnused),
      53, uint(QAmqpQueue::roIfEmpty),
      54, uint(QAmqpQueue::roNoWait),

       0        // eod
};

void QAmqpQueue::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QAmqpQueue *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->declared(); break;
        case 1: _t->bound(); break;
        case 2: _t->unbound(); break;
        case 3: _t->removed(); break;
        case 4: _t->purged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->messageReceived(); break;
        case 6: _t->empty(); break;
        case 7: _t->consuming((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->cancelled((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: _t->declare((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QAmqpTable(*)>(_a[2]))); break;
        case 10: _t->declare((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->declare(); break;
        case 12: _t->bind((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 13: _t->bind((*reinterpret_cast< QAmqpExchange*(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 14: _t->unbind((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 15: _t->unbind((*reinterpret_cast< QAmqpExchange*(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 16: _t->purge(); break;
        case 17: _t->remove((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->remove(); break;
        case 19: { bool _r = _t->consume((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 20: { bool _r = _t->consume();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 21: _t->get((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 22: _t->get(); break;
        case 23: { bool _r = _t->cancel((*reinterpret_cast< bool(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 24: { bool _r = _t->cancel();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 25: _t->ack((*reinterpret_cast< const QAmqpMessage(*)>(_a[1]))); break;
        case 26: _t->ack((*reinterpret_cast< qlonglong(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 27: _t->reject((*reinterpret_cast< const QAmqpMessage(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 28: _t->reject((*reinterpret_cast< qlonglong(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAmqpTable >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QAmqpQueue::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QAmqpQueue::declared)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (QAmqpQueue::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QAmqpQueue::bound)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (QAmqpQueue::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QAmqpQueue::unbound)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (QAmqpQueue::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QAmqpQueue::removed)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (QAmqpQueue::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QAmqpQueue::purged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (QAmqpQueue::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QAmqpQueue::messageReceived)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (QAmqpQueue::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QAmqpQueue::empty)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (QAmqpQueue::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QAmqpQueue::consuming)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (QAmqpQueue::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&QAmqpQueue::cancelled)) {
                *result = 8;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<QAmqpQueue *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->options(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->consumerTag(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<QAmqpQueue *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 1: _t->setConsumerTag(*reinterpret_cast< QString*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject QAmqpQueue::staticMetaObject = { {
    QMetaObject::SuperData::link<QAmqpChannel::staticMetaObject>(),
    qt_meta_stringdata_QAmqpQueue.data,
    qt_meta_data_QAmqpQueue,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *QAmqpQueue::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QAmqpQueue::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_QAmqpQueue.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "QQueue<QAmqpMessage>"))
        return static_cast< QQueue<QAmqpMessage>*>(this);
    return QAmqpChannel::qt_metacast(_clname);
}

int QAmqpQueue::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QAmqpChannel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QAmqpQueue::declared()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void QAmqpQueue::bound()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void QAmqpQueue::unbound()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void QAmqpQueue::removed()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void QAmqpQueue::purged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void QAmqpQueue::messageReceived()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void QAmqpQueue::empty()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void QAmqpQueue::consuming(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void QAmqpQueue::cancelled(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
